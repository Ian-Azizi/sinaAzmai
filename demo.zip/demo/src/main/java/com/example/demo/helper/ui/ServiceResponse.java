package com.example.demo.helper.ui;


import com.example.demo.entites.project.run_project;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ServiceResponse <T> extends run_project implements Serializable {
    private List<T>dataList;
    private ResponseStatus status;
    private boolean hasError;
    private long totalCount;
    private String message;
    public ServiceResponse(List<T> dataList, ResponseStatus status) {
        this.dataList = dataList;
        this.status = status;
        this.message = "";
        this.hasError = false;
        this.totalCount = 1;

    }
    public ServiceResponse(List<T> dataList, ResponseStatus status,long totalCount) {
        this.dataList = dataList;
        this.status = status;
        this.message = "";
        this.hasError = false;
        this.totalCount = totalCount;

    }
    public ServiceResponse(ResponseStatus status,T data) {
        this.dataList = new ArrayList<T>();
        this.dataList.add(data);
        this.status = status;
        this.message = "";
        this.hasError = false;
        this.totalCount = 0;

    }
    public ServiceResponse(boolean status, ResponseStatus message) {
        this.dataList = new ArrayList<T>();
        this.status = ResponseStatus.SUCCESS;
        this.message = "";
        this.hasError = false;
//        this.hasError = status = ResponseStatus.FAILED;
//        this.message = message;

        this.totalCount = 0;


    }
    public ServiceResponse(Exception ex) {
        this.dataList = new ArrayList<T>();
        this.message = message;
        this.status = ResponseStatus.EXCEPTION;
        this.message = ex.getMessage();
        this.hasError = true;
        this.totalCount = 0;

    }

    public List<T> getdataList() {
        return dataList;
    }

    public void setdataList(List<T> dataList) {
        this.dataList = dataList;
    }

    public ResponseStatus getStatus() {
        return status;
    }

    public void setStatus(ResponseStatus status) {
        this.status = status;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(long totalCount) {
        this.totalCount = totalCount;
    }
}
