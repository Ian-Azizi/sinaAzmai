package com.example.demo.Service.user;


import com.example.demo.entites.user.user;
import com.example.demo.helper.exception.DataNotFoundException;
import com.example.demo.repositores.user.userRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class userService {

    @Autowired
    private userRepository repository;
public List<user>findAllByUserNameAndPassWord(String userName,String password){
   List<user>list=new ArrayList<>();
   return repository.findAllByUserNameAndPassWord(userName,password);
}
public List<user>findAllByUsername(String userName){
    List<user>list=new ArrayList<>();
    return repository.findAllByUsername(userName);

}

public List<user>getById(long id){
    Optional<user>data=repository.findById(id);
    if (data.isPresent())return (List<user>) data.get();
    return null;
}
    public user add(user data){
        return repository.save(data);
}
public user upData(user data) throws DataNotFoundException {
    user oldDate = (user) getById (data.getId());
    if (oldDate==null){
        throw new DataNotFoundException("data not found"+data.getId()+"not found");
    }
    oldDate.setTitle(data.getTitle());

    oldDate.setUsername(data.getUsername());
    oldDate.setPassword(data.getPassword());
    oldDate.setTitle(data.getTitle());
    oldDate.setLink(data.getLink());
    return repository.save(data);
}
public boolean deleteById(long id) throws DataNotFoundException {

    user oldDate = (user) getById(id);
    if (oldDate == null){
        throw new DataNotFoundException("data with id" + id + "not found");
    }
    repository.deleteById(id);
return true;
}



}
