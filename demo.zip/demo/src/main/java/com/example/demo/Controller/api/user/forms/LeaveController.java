package com.example.demo.Controller.api.user.forms;

import com.example.demo.Service.user.forms.LeaveService;
import com.example.demo.entites.user.form.Leave;
import com.example.demo.helper.exception.DataNotFoundException;
import com.example.demo.helper.ui.ResponseStatus;
import com.example.demo.helper.ui.ServiceResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RestController("/api/LeaveController")
public class LeaveController {
@Autowired
    private LeaveService service;
@GetMapping("/Leave")
    public ServiceResponse<Leave>getById(long id){
    try{
        List<Leave>result= (List<Leave>) service.getById(id);
        return new ServiceResponse<Leave>(result,ResponseStatus.SUCCESS);
    }catch (Exception e){
        return new ServiceResponse<Leave>(e);
    }
}
@PutMapping("/Leave")
    public ServiceResponse<Leave>add(@PathVariable Leave data){
    try{
        List<Leave>result=service.add(data);
        return new ServiceResponse<Leave>(result,ResponseStatus.SUCCESS);
    }catch (Exception e){
        return new ServiceResponse<Leave>(e);
    }
}
@PostMapping("/Leave")
    public ServiceResponse<Leave>upDate(@PathVariable Leave data) throws DataNotFoundException {
    try{
        List<Leave>result=service.upDate(data);
            return new ServiceResponse<Leave>(result,ResponseStatus.SUCCESS);
        }catch (Exception e){
        return new ServiceResponse<Leave>(e);
    }
}
@DeleteMapping("")
    public ServiceResponse<Leave>delete(@PathVariable long id) throws DataNotFoundException {
    try{
        boolean result = service.deleteById(id);
        return new ServiceResponse<Leave>(result,ResponseStatus.SUCCESS);
    }catch (Exception e){
        return new ServiceResponse<Leave>(e);

    }
}
}
