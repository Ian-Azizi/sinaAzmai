package com.example.demo.Controller.api.user;

import com.example.demo.Service.user.userService;
import com.example.demo.entites.user.user;
import com.example.demo.helper.exception.DataNotFoundException;
import com.example.demo.helper.ui.ResponseStatus;
import com.example.demo.helper.ui.ServiceResponse;
import com.example.demo.helper.uimodels.user.userVM;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RestController("/api/userController")
public class userController {
@Autowired
   private userService service;
@GetMapping("/user")
    public ServiceResponse<user>getById(String userName,String password){
    try{
        List<user> result=service.findAllByUserNameAndPassWord(userName,password);
        return new ServiceResponse<user>(result,ResponseStatus.SUCCESS);
    }catch (Exception e){
        return new ServiceResponse<user>(e);
    }
}
@PutMapping("/user")
public ServiceResponse<user>add(@PathVariable user data){
    try{
        user result=service.add(data);
        return new ServiceResponse<user>(ResponseStatus.SUCCESS,result);
    }catch (Exception e){
       return new ServiceResponse<user>(e);
    }
}
@PostMapping("/user")
public ServiceResponse<user>upData(@PathVariable user data) throws DataNotFoundException {
    try {
        List<user> result = (List<user>) service.upData(data);
        return new ServiceResponse<user>(result, ResponseStatus.SUCCESS);
    } catch (Exception e) {
        return new ServiceResponse<user>(e);
    }
  }
}
