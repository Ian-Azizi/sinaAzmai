package com.example.demo.helper.uimodels.user;

import com.example.demo.entites.user.user;

public class userVM {
private long id;
private String userName;
private String password;
private String Link;
private String title;
private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public userVM(){

}
public userVM(user user2){
    setId(user2.getId());
    setTitle(user2.getTitle());
    setLink(user2.getLink());
    setUserName(user2.getUsername());
    setPassword(user2.getPassword());

}
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getLink() {
        return Link;
    }

    public void setLink(String link) {
        Link = link;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
