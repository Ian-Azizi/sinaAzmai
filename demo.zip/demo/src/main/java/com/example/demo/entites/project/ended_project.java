package com.example.demo.entites.project;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.util.Date;

@Entity
public class ended_project {
    @GeneratedValue
    @Id
    private long id;
    private String title;
    private String link;
    private String image;
    private String description;
    private String customer;
    private String Inspection_Kind;
    private String project_id;
    private Date project_data;
    private long cost;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getInspection_Kind() {
        return Inspection_Kind;
    }

    public void setInspection_Kind(String inspection_Kind) {
        Inspection_Kind = inspection_Kind;
    }

    public String getProject_id() {
        return project_id;
    }

    public void setProject_id(String project_id) {
        this.project_id = project_id;
    }

    public Date getProject_data() {
        return project_data;
    }

    public void setProject_data(Date project_data) {
        this.project_data = project_data;
    }

    public long getCost() {
        return cost;
    }

    public void setCost(long cost) {
        this.cost = cost;
    }
}
