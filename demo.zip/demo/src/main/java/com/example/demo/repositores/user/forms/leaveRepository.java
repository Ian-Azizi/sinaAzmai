package com.example.demo.repositores.user.forms;

import ch.qos.logback.classic.joran.action.LevelAction;
import com.example.demo.entites.user.form.Leave;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.Entity;
import java.util.List;

@Repository
public interface leaveRepository extends PagingAndSortingRepository<Leave,Long> {
List<Leave>findAllById(long id);
List<Leave>findAllByName(String name);

}
