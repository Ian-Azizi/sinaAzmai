package com.example.demo.Controller.api.project_kind;


import com.example.demo.Service.project_kind.project_productService;
import javax.servlet.http.HttpServletRequest;
import com.example.demo.helper.exception.DataNotFoundException;
import com.example.demo.helper.ui.ResponseStatus;
import com.example.demo.helper.ui.ServiceResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.example.demo.entites.project_kind.project_product;
import java.util.List;
import com.example.demo.entites.project_kind.project_product;
@Controller
@RestController("/api/project_product")
public class project_productController {
    private project_productService service;
    @GetMapping("/")
    public ServiceResponse<project_product>get(String company_name){
        try{
            List<project_product>result = service.findAllByCompany_name(company_name);
            return new ServiceResponse<project_product>(result, ResponseStatus.SUCCESS);
        }catch (Exception e){
            return new ServiceResponse<project_product>(e);
        }

    }

    @PostMapping
    public ServiceResponse<project_product>add(@PathVariable project_product Date){
        try{
            project_product result = service.add(Date);
            return new ServiceResponse<project_product>(ResponseStatus.SUCCESS,result);

        }catch (Exception e){
            return new ServiceResponse<project_product>(e);
        }
    }
    @PutMapping("/")
    public ServiceResponse<project_product>upDate(@RequestBody project_product data){
        try{
            project_product result = service.upDate(data);
            return new ServiceResponse<project_product>(ResponseStatus.SUCCESS,result);
        }catch (Exception e){
            return new ServiceResponse<project_product>(e);

        }
    }
    @DeleteMapping("/")
    public ServiceResponse<project_product>delete(long id){
        try{
            boolean result = service.deleteById(id);
            return new ServiceResponse<project_product>(result,ResponseStatus.SUCCESS);
        }catch (Exception e){
            return new ServiceResponse<project_product>(e);

        }
    }

}
