package com.example.demo.Service.project_kind;

import com.example.demo.entites.project_kind.project_product;
import com.example.demo.helper.exception.DataNotFoundException;
import com.example.demo.repositores.project_kind.project_productRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class project_productService {
    @Autowired
private project_productRepository repository;

    public List<project_product>findAllByCompany_name(String Company_name){
        List<project_product>list=new ArrayList<>();
        return repository.findAllByCompany_name(Company_name);
    }
    public List<project_product>findAllById(long id){
        List<project_product>list=new ArrayList<>();
        return repository.findAllById(id);
    }
    public project_product getById(long id){
        Optional<project_product>data = repository.findById(id);
        if (data.isPresent())return data.get();
        return null;
        
    }
    public project_product add(project_product data){
        return repository.save(data);
    }
    public project_product upDate(project_product data) throws DataNotFoundException {
        project_product oldDate = getById (data.getId());
        if (oldDate==null){
            throw new DataNotFoundException("data not found"+data.getId()+"not found");
        }
        oldDate.setTitle(data.getTitle());
        oldDate.setLink(data.getLink());
        oldDate.setDescription(data.getDescription());
        oldDate.setBill_lading(data.getBill_lading());
        oldDate.setConnector(data.getConnector());
        oldDate.setProject_Date(data.getProject_Date());
        oldDate.setAddress(data.getAddress());
        oldDate.setCheck_on_marking(data.isCheck_on_marking());
        oldDate.setCompany_name(data.getCompany_name());
        oldDate.setCottage_num(data.getCottage_num());
        oldDate.setCottage_payed_num(data.getCottage_payed_num());
        oldDate.setEconomic_code(data.getEconomic_code());
        oldDate.setEmail(data.getEmail());
        oldDate.setFex(data.getFex());
        oldDate.setInspection_Certification(data.isInspection_Certification());
        oldDate.setNamouna_bardari(data.isNamouna_bardari());
        oldDate.setNational_ID(data.getNational_ID());
        oldDate.setOther_Certification(data.getOther_Certification());
        oldDate.setProduct_Certification(data.isProduct_Certification());

        oldDate.setProject_num(data.getProject_num());
        oldDate.setProject_Register(data.getProject_Register());
        oldDate.setTel_phone(data.getTel_phone());

        return repository.save(data);
    }
    public boolean deleteById(long id) throws DataNotFoundException {
        project_product oldDate = getById(id);
        if (oldDate == null){
            throw new DataNotFoundException("data with id" + id + "not found");
        }
        repository.deleteById(id);
        return true;
    }



}


