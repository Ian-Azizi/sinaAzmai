package com.example.demo.entites.project_kind;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.util.Date;

@Entity
public class project_product {
@GeneratedValue
    @Id
    private long id;
private String title;
private String link;
private String description;
private boolean namouna_bardari;
private boolean check_on_marking;
private boolean Inspection_Certification;
private boolean product_Certification;
private String other_Certification;
    private long project_num;
private long project_Register;
private String company_name;
private long tel;
private long fex;
private long Economic_code;
private String address;
private String Connector;
private String tel_phone;
private String email;
private long National_ID;
private long Cottage_num;
private long Cottage_payed_num;
private long bill_lading;
//private long profarma_num;
private Date project_Date;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isNamouna_bardari() {
        return namouna_bardari;
    }

    public void setNamouna_bardari(boolean namouna_bardari) {
        this.namouna_bardari = namouna_bardari;
    }

    public boolean isCheck_on_marking() {
        return check_on_marking;
    }

    public void setCheck_on_marking(boolean check_on_marking) {
        this.check_on_marking = check_on_marking;
    }

    public boolean isInspection_Certification() {
        return Inspection_Certification;
    }

    public void setInspection_Certification(boolean inspection_Certification) {
        Inspection_Certification = inspection_Certification;
    }

    public boolean isProduct_Certification() {
        return product_Certification;
    }

    public void setProduct_Certification(boolean product_Certification) {
        this.product_Certification = product_Certification;
    }

    public String getOther_Certification() {
        return other_Certification;
    }

    public void setOther_Certification(String other_Certification) {
        this.other_Certification = other_Certification;
    }

    public long getProject_num() {
        return project_num;
    }

    public void setProject_num(long project_num) {
        this.project_num = project_num;
    }

    public long getProject_Register() {
        return project_Register;
    }

    public void setProject_Register(long project_Register) {
        this.project_Register = project_Register;
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public long getTel() {
        return tel;
    }

    public void setTel(long tel) {
        this.tel = tel;
    }

    public long getFex() {
        return fex;
    }

    public void setFex(long fex) {
        this.fex = fex;
    }

    public long getEconomic_code() {
        return Economic_code;
    }

    public void setEconomic_code(long economic_code) {
        Economic_code = economic_code;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getConnector() {
        return Connector;
    }

    public void setConnector(String connector) {
        Connector = connector;
    }

    public String getTel_phone() {
        return tel_phone;
    }

    public void setTel_phone(String tel_phone) {
        this.tel_phone = tel_phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getNational_ID() {
        return National_ID;
    }

    public void setNational_ID(long national_ID) {
        National_ID = national_ID;
    }

    public long getCottage_num() {
        return Cottage_num;
    }

    public void setCottage_num(long cottage_num) {
        Cottage_num = cottage_num;
    }

    public long getCottage_payed_num() {
        return Cottage_payed_num;
    }

    public void setCottage_payed_num(long cottage_payed_num) {
        Cottage_payed_num = cottage_payed_num;
    }

    public long getBill_lading() {
        return bill_lading;
    }

    public void setBill_lading(long bill_lading) {
        this.bill_lading = bill_lading;
    }



    public Date getProject_Date() {
        return project_Date;
    }

    public void setProject_Date(Date project_Date) {
        this.project_Date = project_Date;
    }
}
