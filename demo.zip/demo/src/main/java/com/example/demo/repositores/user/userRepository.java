package com.example.demo.repositores.user;

import com.example.demo.entites.user.user;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface userRepository extends PagingAndSortingRepository<user,Long> {
    @Query(value="select * from UserName",nativeQuery=true)
    List<user>findAllByUsername(String userName);
    @Query(value="select * from UserName and password",nativeQuery=true)
    List<user>findAllByUserNameAndPassWord(String userName,String password);
    List<user>findAllById(long id);
}
