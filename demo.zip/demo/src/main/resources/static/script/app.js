(function(){
    'use strict';
    var app = angular.module('myApp',['ngRoute','myApp.controller']);

    app.config(function($routeProvider) {
        $routeProvider
            .when('/', {
                templateUrl: 'index.html',
                controller: 'HomeController'
            });
    });

})();